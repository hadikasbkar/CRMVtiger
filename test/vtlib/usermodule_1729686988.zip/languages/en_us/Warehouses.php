<?php
$languageStrings = array(
    'Warehouses' => 'Warehouses',
    'SINGLE_Warehouses' => 'Warehouse',
    'LBL_WAREHOUSE_INFORMATION' => 'Warehouse Information',
);
